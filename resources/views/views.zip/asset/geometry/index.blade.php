@extends('layouts.app')
@section('title', 'Geometri GIS')
@section('content')
<x-page-header title="Geometri GIS" icon="ti-map-pin" />
<div class="bg-white border border-slate-200 rounded-xl p-8 text-center">
    <i class="ti ti-map-pin text-4xl text-slate-200 block mb-3"></i>
    <p class="text-slate-400 mb-4">Halaman Geometri GIS</p>
    <a href="{{ route('assets.index') }}" class="text-sm text-sky-600 hover:underline">← Kembali</a>
</div>
@endsection
