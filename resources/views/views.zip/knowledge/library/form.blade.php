@extends('layouts.app')
@section('title', 'Form Koleksi')
@section('content')
<x-page-header title="Form Koleksi" icon="ti-book" />
<div class="bg-white border border-slate-200 rounded-xl p-8 text-center">
    <i class="ti ti-book text-4xl text-slate-200 block mb-3"></i>
    <p class="text-slate-400 mb-4">Halaman Form Koleksi</p>
    <a href="{{ route('library.index') }}" class="text-sm text-sky-600 hover:underline">← Kembali</a>
</div>
@endsection
