<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — WIAKMS BBWS NT II</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="h-full bg-gradient-to-br from-[#0B2545] via-[#0d2d5a] to-[#1a3d6b] font-[Inter]">

<div class="min-h-full flex">

    {{-- Panel kiri — branding ──────────────────────────────── --}}
    <div class="hidden lg:flex flex-col justify-between p-12 w-[45%] relative overflow-hidden">
        {{-- Background decoration --}}
        <div class="absolute inset-0 opacity-10">
            <div class="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-sky-400 blur-3xl"></div>
            <div class="absolute bottom-0 right-0 w-64 h-64 rounded-full bg-blue-400 blur-2xl"></div>
        </div>

        {{-- Logo --}}
        <div class="relative flex items-center gap-4">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-lg">
                <i class="ti ti-droplet-filled-2 text-white text-2xl"></i>
            </div>
            <div>
                <p class="text-white font-bold text-xl">WIAKMS</p>
                <p class="text-sky-300 text-sm">BBWS Nusa Tenggara II</p>
            </div>
        </div>

        {{-- Tagline --}}
        <div class="relative">
            <h1 class="text-white text-4xl font-bold leading-tight mb-4">
                Water Infrastructure<br>Asset & Knowledge<br>
                <span class="text-sky-300">Management System</span>
            </h1>
            <p class="text-slate-300 text-base leading-relaxed">
                Platform terintegrasi untuk pengelolaan aset infrastruktur,
                monitoring proyek dan OP, serta manajemen dokumen
                Balai Besar Wilayah Sungai Nusa Tenggara II.
            </p>

            {{-- Feature list --}}
            <div class="mt-8 space-y-3">
                @foreach([
                    ['ti-building-bridge', 'Inventarisasi & kondisi aset infrastruktur'],
                    ['ti-timeline',        'Monitoring proyek & realisasi'],
                    ['ti-settings-2',      'Rekaman operasi & pemeliharaan'],
                    ['ti-files',           'Manajemen dokumen & arsip digital'],
                    ['ti-map-2',           'Peta GIS sebaran aset'],
                ] as [$icon, $text])
                <div class="flex items-center gap-3 text-slate-300">
                    <div class="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                        <i class="ti {{ $icon }} text-sky-300 text-sm"></i>
                    </div>
                    <span class="text-sm">{{ $text }}</span>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Footer --}}
        <p class="relative text-slate-500 text-xs">
            © {{ date('Y') }} Kementerian PUPR — BBWS Nusa Tenggara II
        </p>
    </div>

    {{-- Panel kanan — form login ───────────────────────────── --}}
    <div class="flex-1 flex items-center justify-center p-6 lg:p-12 bg-white lg:rounded-l-3xl">
        <div class="w-full max-w-md">

            {{-- Mobile logo --}}
            <div class="flex lg:hidden items-center gap-3 mb-8">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center">
                    <i class="ti ti-droplet-filled-2 text-white text-xl"></i>
                </div>
                <div>
                    <p class="font-bold text-slate-800">WIAKMS</p>
                    <p class="text-xs text-slate-500">BBWS Nusa Tenggara II</p>
                </div>
            </div>

            <h2 class="text-2xl font-bold text-slate-800 mb-1">Selamat Datang</h2>
            <p class="text-slate-500 text-sm mb-8">Masuk untuk mengakses sistem</p>

            {{-- Session errors --}}
            @if(session('error'))
            <div class="mb-4 flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
                <i class="ti ti-circle-x text-red-500 flex-shrink-0"></i>
                {{ session('error') }}
            </div>
            @endif

            @if(session('warning'))
            <div class="mb-4 flex items-center gap-3 bg-amber-50 border border-amber-200 text-amber-700 px-4 py-3 rounded-xl text-sm">
                <i class="ti ti-alert-triangle text-amber-500 flex-shrink-0"></i>
                {{ session('warning') }}
            </div>
            @endif

            @if($errors->any())
            <div class="mb-4 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
                @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
                @endforeach
            </div>
            @endif

            {{-- Form --}}
            <form method="POST" action="{{ route('login') }}" class="space-y-4">
                @csrf

                <div>
                    <label for="email" class="block text-sm font-medium text-slate-700 mb-1.5">
                        Email
                    </label>
                    <div class="relative">
                        <i class="ti ti-mail absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                        <input id="email" type="email" name="email" required autofocus
                               value="{{ old('email') }}"
                               placeholder="nama@bbwsnt2.go.id"
                               class="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl text-sm
                                      focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-300
                                      @error('email') border-red-400 bg-red-50 @enderror">
                    </div>
                </div>

                <div>
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="password" class="text-sm font-medium text-slate-700">Password</label>
                        @if(Route::has('password.request'))
                        <a href="{{ route('password.request') }}"
                           class="text-xs text-sky-600 hover:underline">Lupa password?</a>
                        @endif
                    </div>
                    <div class="relative" x-data="{ show: false }">
                        <i class="ti ti-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                        <input id="password" :type="show ? 'text' : 'password'" name="password" required
                               placeholder="••••••••"
                               class="w-full pl-10 pr-10 py-3 border border-slate-200 rounded-xl text-sm
                                      focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-300
                                      @error('password') border-red-400 bg-red-50 @enderror">
                        <button type="button" @click="show = !show"
                                class="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                            <i :class="show ? 'ti-eye-off' : 'ti-eye'" class="ti text-sm"></i>
                        </button>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <input id="remember_me" type="checkbox" name="remember"
                           class="rounded border-slate-300 text-sky-600 focus:ring-sky-500">
                    <label for="remember_me" class="text-sm text-slate-600">Ingat saya</label>
                </div>

                <button type="submit"
                        class="w-full py-3 bg-gradient-to-r from-sky-600 to-blue-700 text-white text-sm
                               font-semibold rounded-xl hover:from-sky-700 hover:to-blue-800
                               focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2
                               transition-all shadow-lg shadow-sky-500/25">
                    Masuk ke Sistem
                </button>
            </form>

            {{-- Register link --}}
            @if(Route::has('register'))
            <p class="text-center text-sm text-slate-500 mt-6">
                Belum punya akun?
                <a href="{{ route('register') }}" class="text-sky-600 font-medium hover:underline">
                    Daftar sekarang
                </a>
            </p>
            @endif

            {{-- Info pending --}}
            <div class="mt-8 bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-500">
                <p class="font-medium text-slate-700 mb-1">
                    <i class="ti ti-info-circle text-sky-500"></i> Informasi
                </p>
                <p>Akun baru memerlukan persetujuan administrator sebelum dapat digunakan.
                   Hubungi admin satker jika akun Anda belum diaktifkan.</p>
            </div>
        </div>
    </div>
</div>

</body>
</html>
