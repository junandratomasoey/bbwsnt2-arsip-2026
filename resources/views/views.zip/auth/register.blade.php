<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun — WIAKMS BBWS NT II</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-full bg-slate-50 font-[Inter] flex items-center justify-center p-4">

<div class="w-full max-w-md">

    {{-- Header --}}
    <div class="text-center mb-8">
        <div class="inline-flex w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-700
                    items-center justify-center shadow-lg shadow-sky-500/30 mb-4">
            <i class="ti ti-droplet-filled-2 text-white text-2xl"></i>
        </div>
        <h1 class="text-2xl font-bold text-slate-800">Daftar Akun WIAKMS</h1>
        <p class="text-slate-500 text-sm mt-1">BBWS Nusa Tenggara II</p>
    </div>

    {{-- Info --}}
    <div class="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 mb-6 flex items-start gap-2.5">
        <i class="ti ti-alert-triangle text-amber-500 text-lg flex-shrink-0 mt-0.5"></i>
        <p class="text-sm text-amber-700">
            Akun baru akan berstatus <strong>pending</strong> hingga disetujui administrator.
            Gunakan email resmi instansi dan isi data dengan benar.
        </p>
    </div>

    {{-- Errors --}}
    @if($errors->any())
    <div class="mb-4 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
        @foreach($errors->all() as $error)
        <p>{{ $error }}</p>
        @endforeach
    </div>
    @endif

    {{-- Form --}}
    <form method="POST" action="{{ route('register') }}"
          class="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-sm">
        @csrf

        <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">
                Nama Lengkap <span class="text-red-500">*</span>
            </label>
            <input type="text" name="name" required value="{{ old('name') }}"
                   placeholder="Nama sesuai SK"
                   class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm
                          focus:outline-none focus:ring-2 focus:ring-sky-500
                          @error('name') border-red-400 @enderror">
        </div>

        <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">NIP</label>
            <input type="text" name="nip" value="{{ old('nip') }}"
                   placeholder="18 digit NIP ASN (opsional)"
                   maxlength="18"
                   class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-mono
                          focus:outline-none focus:ring-2 focus:ring-sky-500">
        </div>

        <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">
                Email <span class="text-red-500">*</span>
            </label>
            <input type="email" name="email" required value="{{ old('email') }}"
                   placeholder="nama@bbwsnt2.go.id atau Gmail"
                   class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm
                          focus:outline-none focus:ring-2 focus:ring-sky-500
                          @error('email') border-red-400 @enderror">
        </div>

        <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">Jabatan</label>
            <input type="text" name="jabatan_struktural" value="{{ old('jabatan_struktural') }}"
                   placeholder="Jabatan struktural/fungsional"
                   class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm
                          focus:outline-none focus:ring-2 focus:ring-sky-500">
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="block text-xs font-medium text-slate-600 mb-1">
                    Password <span class="text-red-500">*</span>
                </label>
                <input type="password" name="password" required
                       placeholder="Min. 8 karakter"
                       class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm
                              focus:outline-none focus:ring-2 focus:ring-sky-500
                              @error('password') border-red-400 @enderror">
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-600 mb-1">
                    Konfirmasi <span class="text-red-500">*</span>
                </label>
                <input type="password" name="password_confirmation" required
                       placeholder="Ulangi password"
                       class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm
                              focus:outline-none focus:ring-2 focus:ring-sky-500">
            </div>
        </div>

        <button type="submit"
                class="w-full py-3 bg-gradient-to-r from-sky-600 to-blue-700 text-white text-sm
                       font-semibold rounded-xl hover:from-sky-700 hover:to-blue-800
                       focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2
                       transition-all shadow-lg shadow-sky-500/25 mt-2">
            Daftar Akun
        </button>

        <p class="text-center text-sm text-slate-500 pt-2">
            Sudah punya akun?
            <a href="{{ route('login') }}" class="text-sky-600 font-medium hover:underline">Masuk</a>
        </p>
    </form>

    <p class="text-center text-xs text-slate-400 mt-6">
        © {{ date('Y') }} Kementerian PUPR — BBWS Nusa Tenggara II
    </p>
</div>

</body>
</html>
